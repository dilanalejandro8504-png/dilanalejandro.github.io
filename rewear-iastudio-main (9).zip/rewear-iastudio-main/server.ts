import express from "express";
import path from "path";
import { Resend } from "resend";

async function startServer() {
  const app = express();
  const PORT = process.env.PORT || 3000;

  app.use(express.json());

  // Health check
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // API Route to send verification code
  app.post("/api/send-code", async (req, res) => {
    const { email, code } = req.body;

    if (!email || !code) {
      return res.status(400).json({ error: "Email and code are required." });
    }

    const apiKey = process.env.RESEND_API_KEY;
    if (!apiKey) {
      console.warn("RESEND_API_KEY missing, logging code to console only.");
      console.log(`Mock Email Sent to ${email} with code ${code}`);
      return res.json({ success: true, warning: "Mock email sent" });
    }

    try {
      const resend = new Resend(apiKey);
      const data = await resend.emails.send({
        from: "REWEAR Global Solution <onboarding@resend.dev>",
        to: email,
        subject: `[REWEAR] Tu código de seguridad: ${code}`,
        html: `
          <div style="background-color: #020202; color: #ffffff; padding: 40px; font-family: sans-serif; text-align: center;">
            <img src="https://static.wixstatic.com/media/ba62c1_3bd793be8e85481d9f8dfba94ab7c6f0~mv2.png" alt="REWEAR" style="height: 48px; margin-bottom: 24px;" />
            <p style="font-size: 16px; margin-bottom: 24px; font-weight: bold; color: #ffffff;">REWEAR</p>
            <p style="font-size: 14px; margin-bottom: 32px; color: #cccccc;">
              Tu código de acceso para REWEAR es: <strong style="font-size: 24px; letter-spacing: 0.2em; display: inline-block; margin-top: 16px; color: #ffffff;">${code}</strong>
            </p>
            <p style="font-size: 12px; color: #aaaaaa;">
              Este código expira en 10 minutos.
            </p>
          </div>
        `,
      });
      res.json({ success: true, data });
    } catch (error) {
      console.error("Resend error:", error);
      res.status(500).json({ error: "Failed to send email." });
    }
  });

  // Vite middleware setup
  const isProd = process.env.NODE_ENV === "production";
  if (!isProd) {
    try {
      const { createServer: createViteServer } = await import("vite");
      const vite = await createViteServer({
        server: { middlewareMode: true },
        appType: "spa",
      });
      app.use(vite.middlewares);
    } catch (error) {
      console.warn("Vite not available, falling back to static build.");
      const distPath = path.join(process.cwd(), "dist");
      app.use(express.static(distPath));
      app.get("*", (req, res) => {
        res.sendFile(path.join(distPath, "index.html"));
      });
    }
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    // Express 5.x uses *all to handle everything, but React apps typically only need *
    // we use '*' for catch-all fallback since we are using Express 4.x
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
