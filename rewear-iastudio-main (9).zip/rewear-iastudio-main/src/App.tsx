import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Clock,
  ShieldCheck,
  Zap,
  Lock,
  CreditCard,
  CheckCircle2,
  ChevronRight,
  ChevronLeft,
  ChevronUp,
  MessageSquare,
  ThumbsUp,
  Mail,
  Copy,
  Check,
  Building,
  MessageCircle,
  Calendar,
  Hourglass,
  ShoppingCart,
  Users,
  X,
  ChevronDown,
  Star,
  User,
} from "lucide-react";
import { AIChat } from "./components/AIChat";
import { WelcomeScreen } from "./components/WelcomeScreen";
import { AuthScreen } from "./components/AuthScreen";
import { VerificationScreen } from "./components/VerificationScreen";
import {
  FaCcVisa,
  FaCcMastercard,
  FaCcAmex,
  FaApplePay,
  FaFacebook,
  FaInstagram,
  FaYoutube,
  FaLinkedin,
  FaEnvelope,
} from "react-icons/fa";

const SERVICES_DATA = [
  {
    id: "s1",
    title: "AUTOMATIZACIÓN DE REDES SOCIALES + CONEXIÓN (RSS) FACEBOOK",
    desc: "Ideal para empresas que pierden tiempo publicando manualmente.",
    longDesc:
      "Con este kit, conectamos tus fuentes de noticias y las publicamos automáticamente en tu página de Facebook mediante una integración RSS, ahorrándote horas semanales.",
    includes: [
      "Configuración de disparadores automáticos",
      "Sincronización de fuente RSS a tu página",
      "Pruebas de latencia y publicación",
    ],
    oldPrice: "$ 50.000",
    price: "$ 24.990",
    stock: 30,
  },
  {
    id: "s2",
    title:
      "MIGRACIÓN Y DESPLIEGUE WEB + CONFIGURACIÓN DE CERTIFICADO DE SEGURIDAD",
    desc: "Perfecto para negocios que tienen su web caída o con errores técnicos para estar online.",
    longDesc:
      "Movemos tu web actual al alojamiento que nos indiques, instalando el certificado SSL (candado verde) y verificando que nada se rompa en el proceso.",
    includes: [
      "Alojamiento base configurado",
      "Migración de archivos sin pérdida",
      "Certificado SSL (https) forzado",
    ],
    oldPrice: "$ 60.000",
    price: "$ 29.990",
    stock: 30,
  },
  {
    id: "s3",
    title:
      "CONFIGURACIÓN DE PASARELA DE PAGO + INTEGRACIÓN DE BOTONES EN TU SITIO",
    desc: "Para empresas que necesitan empezar a cobrar de inmediato de forma conectada.",
    longDesc:
      "Dejamos lista la integración entre tu banco, la pasarela de pago y tu sitio web para que tus clientes puedan comprar sin fricciones.",
    includes: [
      "Apertura o configuración de cuenta",
      "Creación de producto o links fijos",
      "Integración visual de botones en la Web",
    ],
    oldPrice: "$ 30.000",
    price: "$ 14.990",
    stock: 30,
  },
  {
    id: "s4",
    title: "CHATBOT AUTOMATIZADO BÁSICO + INSTALACIÓN (WHATSAPP O WEB)",
    desc: "Ataca el problema de las empresas que pierden clientes por demorar en responder.",
    longDesc:
      "Diseñamos e instalamos un menú de bienvenida en WhatsApp para pre-calificar a tus prospectos y darles la información correcta las 24 horas del día.",
    includes: [
      "Flujo de bienvenida corporativo",
      "Menú de respuestas estructuradas",
      "Integración oficial con tu canal",
    ],
    oldPrice: "$ 40.000",
    price: "$ 19.990",
    stock: 30,
  },
  {
    id: "s5",
    title: "REVISIÓN Y REPARACIÓN (API / BACKEND) + GARANTÍA ANTI CAÍDAS",
    desc: 'El servicio "bombero" para empresas que tienen su sistema roto.',
    longDesc:
      "Entramos a tu código fuente para identificar y solucionar caídas recurrentes, protegiendo puntos sensibles y devolviendo la estabilidad.",
    includes: [
      "Inspección de logs y diagnósticos",
      "Ejecución de parche de rescate",
      "Cierre de vulnerabilidad detectada",
    ],
    oldPrice: "$ 70.000",
    price: "$ 34.990",
    stock: 30,
  },
  {
    id: "s6",
    title: "SISTEMA DE AGENDAMIENTO AUTOMÁTICO ONLINE",
    desc: "Libérate de agendar citas manualmente por chat o teléfono.",
    longDesc:
      "Implementamos un sistema donde tus clientes ven tus horarios disponibles, reservan solos y el sistema te lo sincroniza en tu calendario personal.",
    includes: [
      "Creación de tipos de citas/servicios",
      "Sincronización con Google Calendar",
      "Recordatorios automáticos por email",
    ],
    oldPrice: "$ 55.000",
    price: "$ 27.990",
    stock: 30,
  },
  {
    id: "s7",
    title: "INTEGRACIÓN DE CRM BÁSICO CON TUS FORMULARIOS",
    desc: "Para que no se te pierda ni un solo potencial cliente.",
    longDesc:
      "Conectamos los formularios de tu página web directamente a una herramienta de gestión (CRM) o a una planilla de Google Sheets automática.",
    includes: [
      "Conexión de hasta 3 formularios",
      "Configuración de base de datos base",
      "Mapeo de campos esenciales",
    ],
    oldPrice: "$ 45.000",
    price: "$ 22.990",
    stock: 30,
  },
  {
    id: "s8",
    title: "SISTEMA DE FACTURACIÓN ELECTRÓNICA AUTOMÁTICO",
    desc: "Emite boletas y facturas de forma automática tras cada venta.",
    longDesc:
      "Conectamos tu tienda con el servicio de Impuestos Internos para que no tengas que emitir documentos manualmente nunca más.",
    includes: [
      "Configuración de documentos DTE",
      "Sincronización con SII",
      "Pruebas de emisión",
    ],
    oldPrice: "$ 60.000",
    price: "$ 29.990",
    stock: 30,
  },
  {
    id: "s9",
    title: "AUDITORÍA TÉCNICA Y OPTIMIZACIÓN DE RENDIMIENTO",
    desc: "Acelera y protege la carga de tu sitio web para no perder clientes.",
    longDesc:
      "Realizamos un análisis exhaustivo y aplicamos técnicas avanzadas para minimizar el tiempo de carga y mejorar el SEO técnico general de tu sitio.",
    includes: [
      "Compresión de recursos estáticos",
      "Configuración de red de distribución CND",
      "Minificación de código CSS/JS",
    ],
    oldPrice: "$ 50.000",
    price: "$ 24.990",
    stock: 30,
  },
];

// Lista de horas bloqueadas manualmente (Puedes editarla para bloquear horarios específicos)
const BLOCKED_SLOTS = ["18:00", "19:30"];

const COUPONS: Record<string, number> = {
  RE2026: 0.2,
  FIRSTREWEAR: 0.15,
  VIPB2B: 0.25,
  FLASH15: 0.15,
  RECORDAHORA: 0.1,
  SOLUCION30: 0.3,
  SYSTEMUP: 0.2,
  PROMO2026: 0.15,
  REWEAR10: 0.1,
  SOCIOS: 0.25,
};

export default function App() {
  const [appState, setAppState] = useState<
    "welcome" | "auth" | "verify" | "app"
  >("welcome");
  const [feedbackSubmitted, setFeedbackSubmitted] = useState(false);
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [isAvailable, setIsAvailable] = useState(false);

  const [userEmail, setUserEmail] = useState<string | null>(null);
  const [userRole, setUserRole] = useState<string | null>(null);

  useEffect(() => {
    // Re-hydrate session from localStorage
    const savedEmail = localStorage.getItem("rewear_user_email");
    if (savedEmail) {
      setUserEmail(savedEmail);
      if (savedEmail.toLowerCase() === "dilan.alejandro8504@gmail.com") {
        setUserRole("admin");
      }
      const verified = localStorage.getItem(`verified_${savedEmail}`);
      if (verified === "true") {
        setAppState("app");
      } else {
        setAppState("verify");
      }
    } else {
      setUserEmail(null);
      setUserRole(null);
      setAppState("welcome");
    }
  }, []);

  useEffect(() => {
    const checkAvailability = () => {
      const now = new Date();
      // Calculate local time in Chile without needing external libraries
      // Chile is generally UTC-4 or UTC-3 (summer). Let's use standard Date manipulation based on timeZone
      const chileTimeStr = now.toLocaleString("en-US", {
        timeZone: "America/Santiago",
      });
      const chileTime = new Date(chileTimeStr);

      const day = chileTime.getDay();
      const hours = chileTime.getHours();
      const minutes = chileTime.getMinutes();
      const timeInMinutes = hours * 60 + minutes;

      // Lunes a Jueves (1-4): 17:30 PM (1050 mins) to 20:30 PM (1230 mins)
      // Viernes (5): 14:20 PM (860 mins) to 17:30 PM (1050 mins)
      // Sábados (6): 08:00 AM (480 mins) to 12:00 PM (720 mins)
      if (
        day >= 1 &&
        day <= 4 &&
        timeInMinutes >= 1050 &&
        timeInMinutes <= 1230
      ) {
        setIsAvailable(true);
      } else if (day === 5 && timeInMinutes >= 860 && timeInMinutes <= 1050) {
        setIsAvailable(true);
      } else if (day === 6 && timeInMinutes >= 480 && timeInMinutes <= 720) {
        setIsAvailable(true);
      } else {
        setIsAvailable(false);
      }
    };

    checkAvailability();
    const interval = setInterval(checkAvailability, 60000);
    return () => clearInterval(interval);
  }, []);

  // States para nuevas funcionalidades
  const [cart, setCart] = useState<
    { id: string; title: string; price: string }[]
  >([]);
  const [expandedService, setExpandedService] = useState<string | null>(null);
  const [promoCode, setPromoCode] = useState("");
  const [activeCoupon, setActiveCoupon] = useState<{
    code: string;
    discount: number;
  } | null>(null);
  const [promoMessage, setPromoMessage] = useState<{
    text: string;
    type: "success" | "error";
  } | null>(null);
  const [paymentMethod, setPaymentMethod] = useState<"transfer" | "card">(
    "transfer",
  );
  const [otrosNeed, setOtrosNeed] = useState("");
  const [otrosBudget, setOtrosBudget] = useState<number | "">("");

  const urlParams =
    typeof window !== "undefined"
      ? new URLSearchParams(window.location.search)
      : null;
  const isAdmin =
    urlParams?.get("view") === "admin" ||
    userRole === "admin" ||
    userEmail === "dilan.alejandro8504@gmail.com";

  const todayMidnight = new Date();
  todayMidnight.setHours(0, 0, 0, 0);

  const [currentMonthDate, setCurrentMonthDate] = useState(() => {
    const d = new Date();
    d.setHours(0, 0, 0, 0);
    return new Date(d.getFullYear(), d.getMonth(), 1);
  });

  const [selectedDate, setSelectedDate] = useState<Date | null>(todayMidnight);

  const handleDirectSchedule = (slot: string) => {
    if (!selectedDate) return;
    let cartDetails = "";
    if (cart.length > 0) {
      cartDetails =
        "\n\nSERVICIOS EN CARRITO: " +
        cart.map((item, i) => `${i + 1}. ${item.title}`).join(", ");
    }
    const formatedDate = selectedDate.toLocaleDateString("es-ES", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    });
    const message = `Hola REWEAR, vi en la web que el día ${formatedDate} a las ${slot} está disponible. Me gustaría solicitar esa sesión para mi negocio.${cartDetails}`;
    window.open(
      `https://wa.me/56921887023?text=${encodeURIComponent(message)}`,
      "_blank",
    );
  };

  const getPriceNumber = (priceStr: string) =>
    parseInt(priceStr.replace(/[^0-9]/g, ""), 10);
  const subtotal = cart.reduce(
    (acc, item) => acc + getPriceNumber(item.price),
    0,
  );
  const discountAmount = activeCoupon ? subtotal * activeCoupon.discount : 0;
  const totalAmount = subtotal - discountAmount;
  const formatPrice = (amount: number) => `$ ${amount.toLocaleString("es-CL")}`;

  const handleApplyPromo = () => {
    const code = promoCode.trim().toUpperCase();
    if (COUPONS[code]) {
      setActiveCoupon({ code, discount: COUPONS[code] });
      setPromoMessage({ text: "¡Cupón aplicado con éxito!", type: "success" });
    } else {
      setActiveCoupon(null);
      setPromoMessage({ text: "Código no válido", type: "error" });
    }
  };

  const handleCheckout = () => {
    if (cart.length === 0) {
      alert("Añade servicios al carrito primero");
      return;
    }
    const listText = cart.map((item, i) => `${item.title}`).join(", ");
    const dateText = selectedDate
      ? selectedDate.toLocaleDateString("es-ES", {
          weekday: "long",
          day: "numeric",
          month: "long",
        })
      : "Fecha por definir";
    let message = "";

    if (paymentMethod === "card") {
      message = `Hola REWEAR, quiero solicitar un servicio. Datos de la compra simulada: ${listText}, ${dateText}. Necesito: Implementación. Pago realizado (simulado) con Tarjeta.`;
    } else {
      message = `Hola REWEAR, quiero solicitar el servicio ${listText} para el día ${dateText} en horario a convenir. Ingresaré mi comprobante a continuación. Por favor atiéndanme en segundos.`;
    }

    if (activeCoupon) {
      message += ` Cupón: ${activeCoupon.code} aplicado.`;
    }
    message += ` Total: ${formatPrice(totalAmount)}`;

    window.open(
      `https://wa.me/56921887023?text=${encodeURIComponent(message)}`,
      "_blank",
    );
  };

  const getSlotStatus = (slotTimeStr: string, date: Date) => {
    if (BLOCKED_SLOTS.includes(slotTimeStr)) return "blocked";

    const now = new Date();
    if (date.getTime() === todayMidnight.getTime()) {
      const [slotH, slotM] = slotTimeStr.split(":").map(Number);
      if (
        now.getHours() > slotH ||
        (now.getHours() === slotH && now.getMinutes() >= slotM)
      ) {
        return "past";
      }
    }
    return "available";
  };

  const addToCart = (service: any) => {
    if (cart.length >= 5) {
      alert("Máximo 5 servicios por carrito.");
      return;
    }
    if (cart.some((item) => item.id === service.id)) {
      alert("Este servicio ya está en tu carrito.");
      return;
    }
    setCart([...cart, service]);
  };

  const removeFromCart = (id: string) => {
    setCart(cart.filter((item) => item.id !== id));
  };

  const [currentReviewIndex, setCurrentReviewIndex] = useState(0);
  const [isHoveringReviews, setIsHoveringReviews] = useState(false);

  useEffect(() => {
    if (isHoveringReviews) return;
    const interval = setInterval(() => {
      setCurrentReviewIndex((prev) => (prev + 1) % 3);
    }, 5000);
    return () => clearInterval(interval);
  }, [isHoveringReviews]);

  const copyToClipboard = (text: string, field: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(field);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const year = currentMonthDate.getFullYear();
  const month = currentMonthDate.getMonth();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const firstDayOfMonth = new Date(year, month, 1).getDay();

  const calendarDays = [];
  for (let i = 0; i < firstDayOfMonth; i++) {
    calendarDays.push(null);
  }
  for (let i = 1; i <= daysInMonth; i++) {
    calendarDays.push(new Date(year, month, i));
  }

  const isDaySelectable = (date: Date) =>
    date >= todayMidnight && date.getDay() !== 0;

  if (appState === "welcome" || appState === "auth" || appState === "verify") {
    return (
      <div className="relative min-h-screen">
        <AnimatePresence>
          {appState === "welcome" && (
            <WelcomeScreen
              key="welcome"
              onDismiss={() => setAppState("auth")}
            />
          )}
        </AnimatePresence>
        {appState === "auth" && (
          <AuthScreen
            onLogin={(email) => {
              localStorage.setItem("rewear_user_email", email);
              setUserEmail(email);
              if (email.toLowerCase() === "dilan.alejandro8504@gmail.com") {
                setUserRole("admin");
              } else {
                setUserRole("user");
              }
              const verified = localStorage.getItem(`verified_${email}`);
              if (verified === "true") {
                setAppState("app");
              } else {
                setAppState("verify");
              }
            }}
          />
        )}
        {appState === "verify" && (
          <VerificationScreen
            email={userEmail}
            onVerify={() => {
              if (userEmail) {
                localStorage.setItem(`verified_${userEmail}`, "true");
              }
              setAppState("app");
            }}
            onCancel={() => {
              localStorage.removeItem("rewear_user_email");
              setUserEmail(null);
              setUserRole(null);
              setAppState("auth");
            }}
          />
        )}
        <AIChat />
      </div>
    );
  }

  return (
    <div className="min-h-screen font-montserrat flex flex-col text-white relative z-0">
      {/* Animated Background */}
      <div className="bg-animation-wrapper">
        <div className="bg-gradient-orb"></div>
        <div className="bg-gradient-orb-2"></div>
        <div className="bg-grid-overlay"></div>
      </div>

      {/* Floating Cart */}
      <AnimatePresence>
        {cart.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 50, scale: 0.9 }}
            className="fixed bottom-6 right-6 z-[60] bg-black/80 backdrop-blur-md border border-brand-200 rounded-full p-4 shadow-2xl flex items-center gap-4 cursor-pointer hover:border-accent transition-colors"
            onClick={() => {
              const el = document.getElementById("pago");
              el?.scrollIntoView({ behavior: "smooth" });
            }}
          >
            <div className="relative">
              <ShoppingCart className="w-6 h-6 text-white" />
              <span className="absolute -top-2 -right-2 bg-accent text-black text-[10px] font-bold w-5 h-5 flex items-center justify-center rounded-full">
                {cart.length}
              </span>
            </div>
            <div className="hidden md:block pr-2">
              <span className="text-xs uppercase tracking-widest text-white font-bold ml-1">
                Tu Selección
              </span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 bg-brand-900/80 backdrop-blur-md z-50 border-b border-brand-200">
        {isAdmin && (
          <div className="absolute top-0 left-0 right-0 bg-accent text-center text-black text-[10px] font-bold uppercase tracking-widest py-1">
            Modo Editor B2B Activo
          </div>
        )}
        <div
          className={`max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between ${isAdmin ? "mt-6" : ""}`}
        >
          <div className="flex items-center gap-3">
            {/* Logo */}
            <img
              src="/logo submarcado sin fondo.png"
              alt="REWEAR"
              className="h-10 object-contain"
              onError={(e) => (e.currentTarget.style.display = "none")}
            />
          </div>
          <div className="hidden md:flex items-center gap-8">
            <a
              href="#nosotros"
              className="text-sm font-semibold text-brand-400 uppercase tracking-widest hover:text-white transition-colors"
            >
              Nosotros
            </a>
            <a
              href="#como-funciona"
              className="text-sm font-semibold text-brand-400 uppercase tracking-widest hover:text-white transition-colors"
            >
              Ventajas
            </a>
            <a
              href="#servicios"
              className="text-sm font-semibold text-brand-400 uppercase tracking-widest hover:text-white transition-colors"
            >
              Servicios
            </a>
            <a
              href="#agendar"
              className="text-sm font-semibold text-brand-400 uppercase tracking-widest hover:text-white transition-colors"
            >
              Agendar
            </a>
            <a
              href="#pago"
              className="text-sm font-semibold text-brand-400 uppercase tracking-widest hover:text-white transition-colors"
            >
              Checkout
            </a>
          </div>
          <div className="relative group ml-auto md:ml-0">
            <div className="w-10 h-10 bg-[#050505] border border-white/20 rounded-full overflow-hidden flex items-center justify-center cursor-pointer hover:border-white/50 transition-colors">
              <User className="w-5 h-5 text-white/70" />
            </div>
            <div className="absolute right-0 mt-2 w-48 bg-black border border-white/10 rounded-xl shadow-2xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all overflow-hidden z-[100]">
              {isAdmin && (
                <button className="w-full text-left px-4 py-3.5 text-xs text-white hover:bg-white/10 border-b border-white/10 transition-colors uppercase font-bold tracking-widest">
                  Editar Datos
                </button>
              )}
              <button
                onClick={() => {
                  try {
                    if (userEmail) {
                      localStorage.removeItem(`verified_${userEmail}`);
                    }
                    localStorage.removeItem("rewear_user_email");
                    setUserEmail(null);
                    setUserRole(null);
                    setAppState("welcome");
                  } catch (err) {
                    console.error("Error signing out:", err);
                  }
                }}
                className="w-full text-left px-4 py-3.5 text-xs text-red-500 hover:bg-white/10 transition-colors uppercase font-bold tracking-widest"
              >
                Cerrar Sesión
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 md:pt-48 md:pb-32 px-4 sm:px-6 lg:px-8 w-full flex flex-col items-center text-center overflow-hidden min-h-[90vh] justify-center">
        {/* Video Background */}
        <div className="absolute inset-0 z-0">
          <video
            autoPlay
            loop
            muted
            playsInline
            className="w-full h-full object-cover opacity-40 mix-blend-screen"
          >
            {/* Aquí puedes reemplazar el src por la ruta de tu propio video (p. ej., '/video.mp4') si lo subes al proyecto */}
            <source
              src="https://assets.mixkit.co/videos/preview/mixkit-abstract-technology-network-connection-background-27806-large.mp4"
              type="video/mp4"
            />
          </video>
          {/* Gradient Overlay for text readability and blending */}
          <div className="absolute inset-0 bg-gradient-to-b from-brand-900/80 via-transparent to-brand-900" />
          <div className="absolute inset-0 bg-brand-900/50" />
        </div>

        {/* Content */}
        <div className="relative z-10 flex flex-col items-center max-w-7xl mx-auto w-full">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="mb-4"
          >
            <span className="text-sm font-bold text-accent uppercase tracking-[0.3em] bg-black/40 px-4 py-1.5 rounded-full border border-accent/20">
              Automatización de Élite: Tu tiempo es nuestro código.
            </span>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="font-anton text-5xl md:text-7xl lg:text-[90px] tracking-tighter text-white uppercase leading-[0.95] max-w-5xl mb-8"
          >
            Sistemas <span className="text-accent">Eficientes</span> en <br />{" "}
            Menos de 15 Minutos.
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-lg md:text-xl text-brand-400 max-w-3xl mb-12 leading-relaxed"
          >
            En <strong className="text-white font-bold">REWEAR</strong>{" "}
            transformamos los problemas operativos de tu empresa. Somos
            especialistas en implementar soluciones y automatizaciones
            corporativas en tiempo récord. Respaldamos cada integración con una
            garantía total.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="flex flex-col sm:flex-row gap-4 w-full justify-center"
          >
            <a
              href="#servicios"
              className="inline-flex items-center justify-center px-8 py-4 text-base font-bold text-black uppercase tracking-widest bg-accent hover:bg-brand-400 rounded-md transition-all shadow-xl hover:-translate-y-1"
            >
              Comenzar Ahora <ChevronRight className="ml-2 w-5 h-5" />
            </a>
            <a
              href="#como-funciona"
              className="inline-flex items-center justify-center px-8 py-4 text-base font-bold text-white bg-brand-50 border border-brand-200 hover:bg-brand-100 uppercase tracking-widest rounded-md transition-all backdrop-blur-sm"
            >
              Conocer Más
            </a>
          </motion.div>

          {/* System Status Alert */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="mt-12 w-full"
          >
            <div className="font-montserrat bg-brand-900 border border-brand-200 rounded-lg p-5 max-w-sm mx-auto text-center w-full shadow-2xl relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
              <h2 className="relative font-anton uppercase tracking-widest mb-3 text-white text-xl">
                Estado del Sistema
              </h2>
              <div className="relative flex items-center justify-center gap-3 mb-4">
                {isAvailable ? (
                  <>
                    <span className="w-3 h-3 rounded-full bg-[#00ff00] shadow-[0_0_10px_#00ff00] animate-pulse"></span>
                    <span className="font-bold text-sm text-[#00ff00] uppercase tracking-widest">
                      SISTEMA: DISPONIBLE
                    </span>
                  </>
                ) : (
                  <>
                    <span className="w-3 h-3 rounded-full bg-[#ff4444] shadow-[0_0_10px_#ff4444]"></span>
                    <span className="font-bold text-sm text-[#ff4444] uppercase tracking-widest">
                      SISTEMA: NO DISPONIBLE
                    </span>
                  </>
                )}
              </div>
              <p className="relative text-xs text-brand-400 leading-relaxed uppercase tracking-widest font-semibold">
                {isAvailable
                  ? "Estamos listos. Tu solución estará activa en menos de 15 minutos."
                  : "Sistema fuera del horario de atención. Vuelve de Lunes a Jueves (17:30-20:30), Viernes (14:20-17:30) o Sábado (08:00-12:00)."}
              </p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* ¿Quiénes Somos? */}
      <motion.section
        id="nosotros"
        className="py-24 border-y border-brand-200 relative z-10"
        initial={{ opacity: 0, y: 40 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-100px" }}
        transition={{ duration: 0.8, ease: "easeOut" }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-black/60 backdrop-blur-md rounded-xl border border-brand-200 p-8 md:p-14 md:flex items-center gap-12 overflow-hidden relative">
            <div className="md:w-1/2 mb-10 md:mb-0 relative z-10">
              <h2 className="font-anton text-4xl md:text-5xl uppercase tracking-widest text-white mb-6">
                Quiénes <span className="text-accent">Somos</span>
              </h2>
              <p className="text-brand-400 text-sm md:text-base leading-relaxed mb-6">
                <strong className="text-white font-bold">
                  REWEAR GLOBAL SYSTEMS
                </strong>{" "}
                es una agencia tecnológica especializada en{" "}
                <span className="text-white">
                  automatización B2B y resolución técnica inmediata
                </span>
                . No somos la típica agencia de lentos procesos; somos la fuerza
                de choque para tu empresa.
              </p>
              <p className="text-brand-400 text-sm md:text-base leading-relaxed">
                Operamos bajo estándares corporativos rigurosos, garantizando
                soluciones funcionales en un tiempo récord. Si tu web está
                caída, si necesitas cobrar online ahora mismo, o si pierdes
                clientes por falta de respuesta, nosotros entramos, solucionamos
                y respaldamos con garantía técnica total.
              </p>
            </div>
            <div className="md:w-1/2 relative z-10 grid grid-cols-2 gap-4">
              <div className="bg-brand-900 border border-brand-200 p-6 rounded-lg text-center shadow-lg">
                <Building className="w-8 h-8 text-accent mx-auto mb-3" />
                <h3 className="text-white font-bold uppercase tracking-widest text-xs md:text-sm">
                  Respaldo
                </h3>
                <p className="text-brand-400 text-[10px] md:text-xs mt-2 uppercase tracking-widest">
                  Legal y Corporativo
                </p>
              </div>
              <div className="bg-brand-900 border border-brand-200 p-6 rounded-lg text-center shadow-lg">
                <Clock className="w-8 h-8 text-accent mx-auto mb-3" />
                <h3 className="text-white font-bold uppercase tracking-widest text-xs md:text-sm">
                  Velocidad
                </h3>
                <p className="text-brand-400 text-[10px] md:text-xs mt-2 uppercase tracking-widest">
                  Plazos de Minutos
                </p>
              </div>
              <div className="bg-brand-900 border border-brand-200 p-6 rounded-lg text-center shadow-lg">
                <ShieldCheck className="w-8 h-8 text-accent mx-auto mb-3" />
                <h3 className="text-white font-bold uppercase tracking-widest text-xs md:text-sm">
                  Garantía
                </h3>
                <p className="text-brand-400 text-[10px] md:text-xs mt-2 uppercase tracking-widest">
                  Sin fallas técnicas
                </p>
              </div>
              <div className="bg-brand-900 border border-brand-200 p-6 rounded-lg text-center shadow-lg">
                <CheckCircle2 className="w-8 h-8 text-accent mx-auto mb-3" />
                <h3 className="text-white font-bold uppercase tracking-widest text-xs md:text-sm">
                  100% Online
                </h3>
                <p className="text-brand-400 text-[10px] md:text-xs mt-2 uppercase tracking-widest">
                  De principio a fin
                </p>
              </div>
            </div>
          </div>
        </div>
      </motion.section>

      {/* Guarantee & Features */}
      <motion.section
        id="como-funciona"
        className="py-24 bg-black/40 backdrop-blur-sm border-y border-brand-200 relative"
        initial={{ opacity: 0, y: 40 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-100px" }}
        transition={{ duration: 0.8, ease: "easeOut" }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="font-anton text-4xl md:text-5xl uppercase tracking-widest text-white mb-6">
              Agilidad que <span className="text-accent">Escala</span>
            </h2>
            <p className="text-brand-400 text-lg">
              Brindamos la agilidad, seguridad y confianza absoluta que tu
              negocio necesita para operar sin interrupciones.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: Clock,
                title: "Tiempo Récord",
                desc: "Soluciones entregadas y operativas en un lapso de 10 a 15 minutos. No más esperas interminables que frenen tus operaciones.",
              },
              {
                icon: ShieldCheck,
                title: "Garantía Total",
                desc: "Confiamos tanto en nuestros procesos que cada integración está respaldada al 100%. Cero riesgos para tu empresa.",
              },
              {
                icon: Zap,
                title: "Alta Eficiencia",
                desc: "Automatizamos tus cuellos de botella para que tu equipo se concentre en escalar, no en apagar incendios diarios.",
              },
            ].map((feature, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1, duration: 0.5 }}
                className="bg-black/60 backdrop-blur-sm p-8 rounded-xl border border-brand-200 transition-colors hover:border-brand-400"
              >
                <div className="flex items-start gap-4 mb-4">
                  <div className="text-accent font-bold mt-1">✓</div>
                  <div>
                    <h3 className="font-bold text-white mb-2">
                      {feature.title}
                    </h3>
                    <p className="text-brand-400 text-sm leading-relaxed">
                      {feature.desc}
                    </p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </motion.section>

      {/* Services Pricing Kit */}
      <motion.section
        id="servicios"
        className="py-24 border-b border-brand-200"
        initial={{ opacity: 0, y: 40 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-100px" }}
        transition={{ duration: 0.8, ease: "easeOut" }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="font-anton text-4xl md:text-5xl uppercase tracking-widest text-white mb-6">
              Kit de <span className="text-accent">Servicios</span>
            </h2>
            <p className="text-brand-400 text-lg">
              Promociones listas para implementar y solucionar problemas
              técnicos de raíz.
            </p>
          </div>

          <div className="flex flex-col gap-6">
            {SERVICES_DATA.map((service, idx) => (
              <motion.div
                key={service.id}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1, duration: 0.5 }}
                className="bg-black/60 backdrop-blur-sm p-6 md:p-8 rounded-xl border border-brand-200 flex flex-col md:flex-row items-start md:items-center justify-between gap-6 hover:border-brand-400 transition-colors"
              >
                <div className="flex-1 w-full">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-bold text-white text-lg md:text-xl uppercase tracking-widest">
                      {service.title}
                    </h3>
                  </div>
                  <p className="text-brand-400 text-sm md:text-base leading-relaxed mb-5">
                    {service.desc}
                  </p>

                  <AnimatePresence>
                    {expandedService === service.id && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        exit={{ opacity: 0, height: 0 }}
                        className="overflow-hidden mb-4"
                      >
                        <p className="text-sm text-brand-300 mb-4">
                          {service.longDesc}
                        </p>
                        <ul className="space-y-2 mb-4 bg-brand-900 border border-brand-200 p-4 rounded-md">
                          {service.includes.map((inc, i) => (
                            <li
                              key={i}
                              className="flex items-center text-[11px] md:text-xs text-brand-300 uppercase tracking-widest font-semibold"
                            >
                              <Check className="w-3.5 h-3.5 text-accent mr-2.5 flex-shrink-0" />{" "}
                              {inc}
                            </li>
                          ))}
                        </ul>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  <button
                    onClick={() =>
                      setExpandedService(
                        expandedService === service.id ? null : service.id,
                      )
                    }
                    className="flex items-center gap-2 text-xs font-bold text-brand-400 hover:text-white uppercase tracking-widest transition-colors mb-2"
                  >
                    {expandedService === service.id ? (
                      <>
                        <ChevronUp className="w-4 h-4" /> REPLEGAR INFORMACIÓN
                      </>
                    ) : (
                      <>
                        <ChevronDown className="w-4 h-4" /> MÁS INFORMACIÓN
                      </>
                    )}
                  </button>
                </div>
                <div className="flex flex-col md:items-end flex-shrink-0 mt-4 md:mt-0 w-full md:w-auto gap-2 border-t md:border-t-0 md:border-l border-brand-200 pt-4 md:pt-0 md:pl-6">
                  <div className="flex flex-col md:text-right mb-4">
                    <span className="text-xs uppercase tracking-widest text-brand-500 font-bold mb-1">
                      A Solo
                    </span>
                    <div className="flex items-center md:justify-end gap-2">
                      <span className="text-sm font-bold text-brand-500 line-through">
                        {service.oldPrice}
                      </span>
                      <span className="font-anton text-3xl md:text-4xl text-accent">
                        {service.price}
                      </span>
                    </div>
                  </div>
                  <div className="flex flex-col gap-2 w-full">
                    <a
                      href="#pago"
                      onClick={() => {
                        if (!cart.some((i) => i.id === service.id))
                          addToCart(service);
                      }}
                      className="w-full px-6 py-3 bg-accent hover:bg-brand-400 text-black transition-colors rounded-md uppercase text-xs font-bold tracking-widest text-center"
                    >
                      Lo Necesito Ahora
                    </a>
                    <button
                      onClick={() => addToCart(service)}
                      className="w-full px-6 py-3 border border-brand-200 hover:border-brand-400 hover:bg-brand-50 transition-colors rounded-md uppercase text-[10px] font-bold tracking-widest text-center text-white flex items-center justify-center gap-2"
                    >
                      <ShoppingCart className="w-4 h-4" /> Añadir al Carrito
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}

            {/* Custom Option OTROS */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="bg-black/60 border border-brand-200 rounded-xl p-6 md:p-8 hover:border-brand-500 transition-colors backdrop-blur-md relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 bg-brand-50 text-white text-[10px] font-bold px-3 py-1 uppercase tracking-widest border-b border-l border-brand-200 rounded-bl-lg">
                Personalizado
              </div>
              <div className="flex flex-col md:flex-row md:items-start justify-between gap-6">
                <div className="flex-1 w-full">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="bg-brand-900 p-2 rounded border border-brand-200">
                      <CheckCircle2 className="w-5 h-5 text-brand-400" />
                    </div>
                    <h3 className="text-xl font-bold uppercase tracking-widest text-white">
                      OTROS (Servicio a Medida)
                    </h3>
                  </div>
                  <p className="text-brand-400 text-sm mb-4">
                    ¿No encuentras lo que buscas? Cuéntanos tu proceso operativo
                    y diseñaremos una solución técnica específica.
                  </p>

                  <div className="space-y-4 mb-4">
                    <div>
                      <label className="block text-[10px] font-bold uppercase tracking-widest text-brand-500 mb-2">
                        ¿Qué necesitas en pocas palabras? (Máx. 200 caracteres)
                      </label>
                      <textarea
                        maxLength={200}
                        value={otrosNeed}
                        onChange={(e) => setOtrosNeed(e.target.value)}
                        className="w-full bg-black/50 border border-brand-200 rounded-lg p-3 text-sm text-white focus:border-accent focus:outline-none transition-colors resize-none h-24"
                        placeholder="Ej: Necesito integrar mi CRM con Google Sheets y automatizar correos."
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold uppercase tracking-widest text-brand-500 mb-2">
                        Tu presupuesto estimado (Mín. $7.990 CLP)
                      </label>
                      <input
                        type="number"
                        min="7990"
                        value={otrosBudget}
                        onChange={(e) =>
                          setOtrosBudget(Number(e.target.value) || "")
                        }
                        className="w-full bg-black/50 border border-brand-200 rounded-lg p-3 text-sm text-white focus:border-accent focus:outline-none transition-colors"
                        placeholder="Ej: 15000"
                      />
                    </div>
                  </div>
                </div>

                <div className="md:w-64 flex flex-col justify-end pt-4 md:pt-14">
                  <button
                    onClick={() => {
                      if (!otrosNeed || !otrosBudget || otrosBudget < 7990) {
                        alert(
                          "Por favor completa los campos y añade un presupuesto mínimo de $7.990 CLP.",
                        );
                        return;
                      }
                      const msg = `Hola REWEAR, necesito un presupuesto personalizado.\n\nDetalle: ${otrosNeed}\n\nPresupuesto Estimado: $${otrosBudget}`;
                      window.open(
                        `https://wa.me/56921887023?text=${encodeURIComponent(msg)}`,
                        "_blank",
                      );
                    }}
                    className="w-full bg-brand-800 hover:bg-brand-700 text-white border border-brand-200 rounded-lg py-4 px-2 text-[10px] font-bold uppercase tracking-[0.15em] transition-colors flex items-center justify-center text-center shadow-lg leading-normal"
                  >
                    Solicitar Presupuesto Personalizado
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </motion.section>

      {/* Agendamiento Inteligente Section (Calendario Mensual) */}
      <motion.section
        id="agendar"
        className="py-24 border-b border-brand-200 relative z-10"
        initial={{ opacity: 0, y: 40 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-100px" }}
        transition={{ duration: 0.8, ease: "easeOut" }}
      >
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="font-anton text-4xl md:text-5xl uppercase tracking-widest text-white mb-2">
              Selector de <span className="text-accent">Día y Hora</span>
            </h2>
            <p className="text-xs uppercase tracking-widest text-brand-300 font-bold mb-6">
              Fricción Cero: Selecciona tu bloque y agenda directamente vía
              WhatsApp
            </p>
          </div>

          <div className="bg-black/80 backdrop-blur-md border border-brand-200 rounded-xl p-6 md:p-8 shadow-2xl overflow-hidden mx-auto max-w-2xl">
            {/* Header Calendario */}
            <div className="flex items-center justify-between mb-8">
              <h3 className="font-anton text-2xl uppercase tracking-widest text-white">
                {currentMonthDate.toLocaleDateString("es-ES", {
                  month: "long",
                  year: "numeric",
                })}
              </h3>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    const prev = new Date(year, month - 1, 1);
                    if (
                      prev.getFullYear() > todayMidnight.getFullYear() ||
                      (prev.getFullYear() === todayMidnight.getFullYear() &&
                        prev.getMonth() >= todayMidnight.getMonth())
                    ) {
                      setCurrentMonthDate(prev);
                    }
                  }}
                  className="p-2 border border-brand-200 rounded hover:bg-brand-900 transition-colors"
                >
                  <ChevronLeft className="w-5 h-5 text-brand-400" />
                </button>
                <button
                  onClick={() =>
                    setCurrentMonthDate(new Date(year, month + 1, 1))
                  }
                  className="p-2 border border-brand-200 rounded hover:bg-brand-900 transition-colors"
                >
                  <ChevronRight className="w-5 h-5 text-brand-400" />
                </button>
              </div>
            </div>

            {/* Grid Calendario */}
            <div className="grid grid-cols-7 gap-2 text-center mb-2">
              {["Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"].map((d) => (
                <div
                  key={d}
                  className="text-[10px] text-brand-500 font-bold uppercase tracking-widest"
                >
                  {d}
                </div>
              ))}
            </div>

            <div className="grid grid-cols-7 gap-2 mb-8">
              {calendarDays.map((day, idx) => {
                if (!day) return <div key={idx} className="h-10 md:h-12" />; // empty slot

                const isSelectable = isDaySelectable(day);
                const isSelected = selectedDate?.getTime() === day.getTime();
                const isToday = day.getTime() === todayMidnight.getTime();

                return (
                  <button
                    key={idx}
                    disabled={!isSelectable}
                    onClick={() => setSelectedDate(day)}
                    className={`h-10 md:h-12 rounded-lg text-sm font-bold flex items-center justify-center transition-all outline-none ${
                      !isSelectable
                        ? "text-brand-700 cursor-not-allowed opacity-50"
                        : isSelected
                          ? "bg-accent text-black shadow-[0_0_15px_rgba(202,255,0,0.5)] scale-110 relative z-10"
                          : "bg-brand-900 text-brand-300 hover:bg-brand-700 hover:text-white border border-transparent cursor-pointer"
                    } ${isToday && !isSelected ? "border-accent text-accent" : ""}`}
                  >
                    {day.getDate()}
                  </button>
                );
              })}
            </div>

            {/* Slots Disponibles */}
            <AnimatePresence mode="wait">
              <motion.div
                key={selectedDate?.getTime() || "none"}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.3 }}
              >
                {selectedDate && (
                  <>
                    <h4 className="text-xs uppercase tracking-widest text-brand-400 font-bold mb-4 flex justify-between items-center border-t border-brand-200/50 pt-6">
                      <span>
                        Horarios para el{" "}
                        {selectedDate.toLocaleDateString("es-ES", {
                          day: "numeric",
                          month: "short",
                        })}
                      </span>
                      {isAdmin && (
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() =>
                              alert("Limpiando agenda... (Simulación)")
                            }
                            className="text-[9px] bg-red-900/20 text-red-400 hover:bg-red-900/50 hover:text-red-300 px-2 py-0.5 rounded border border-red-500/30 transition-colors uppercase cursor-pointer"
                          >
                            Limpiar Agenda
                          </button>
                          <span className="text-[9px] bg-red-900/50 text-red-400 px-2 py-0.5 rounded border border-red-500/50">
                            Admin View
                          </span>
                        </div>
                      )}
                    </h4>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                      {(selectedDate.getDay() >= 1 && selectedDate.getDay() <= 4
                        ? ["17:30", "18:00", "18:30", "19:00", "19:30", "20:00"]
                        : selectedDate.getDay() === 5
                          ? [
                              "14:20",
                              "15:00",
                              "15:30",
                              "16:00",
                              "16:30",
                              "17:00",
                            ]
                          : selectedDate.getDay() === 6
                            ? [
                                "08:00",
                                "08:30",
                                "09:00",
                                "09:30",
                                "10:00",
                                "10:30",
                                "11:00",
                                "11:30",
                              ]
                            : []
                      ).map((slot) => {
                        const status = getSlotStatus(slot, selectedDate);
                        const disabled = status !== "available";

                        if (status === "blocked" && isAdmin) {
                          return (
                            <button
                              key={slot}
                              disabled
                              className="py-3 rounded text-[10px] font-bold uppercase tracking-widest transition-all bg-red-950/40 border border-red-900 text-red-500 flex justify-center items-center gap-1.5"
                            >
                              <Lock className="w-3 h-3" />
                              {slot}
                            </button>
                          );
                        }

                        return (
                          <button
                            key={slot}
                            disabled={disabled}
                            onClick={() => handleDirectSchedule(slot)}
                            className={`py-3 rounded font-bold text-[11px] uppercase tracking-widest transition-all border flex gap-2 items-center justify-center ${
                              disabled
                                ? "bg-black/50 border-brand-800 text-brand-700 cursor-not-allowed"
                                : "bg-brand-900 border-brand-200 text-white hover:bg-accent hover:text-black hover:border-accent shadow-sm"
                            }`}
                          >
                            <Clock className="w-3.5 h-3.5" />
                            {disabled
                              ? status === "blocked"
                                ? "Ocupado"
                                : "Pasado"
                              : slot}
                          </button>
                        );
                      })}
                    </div>
                  </>
                )}
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </motion.section>

      {/* Secure Checkout / Pricing Area */}
      <motion.section
        id="pago"
        className="py-24 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 w-full relative z-10"
        initial={{ opacity: 0, y: 40 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-100px" }}
        transition={{ duration: 0.8, ease: "easeOut" }}
      >
        <div className="bg-black/40 backdrop-blur-md border border-brand-200 rounded-xl overflow-hidden flex flex-col md:flex-row">
          {/* Info Side */}
          <div className="bg-black/60 p-10 md:p-14 text-white md:w-2/5 flex flex-col justify-between border-r border-brand-200">
            <div>
              <h3 className="font-bold tracking-widest uppercase text-sm mb-4 text-accent">
                Automatización B2B
              </h3>
              <p className="text-brand-400 text-sm font-medium mb-8">
                Solución completa e integración inmediata.
              </p>

              <ul className="space-y-4 mb-10">
                {[
                  "Auditoría Express",
                  "Implementación (10-15 min)",
                  "Soporte Prioritario B2B",
                  "Garantía Extendida",
                ].map((item, i) => (
                  <li
                    key={i}
                    className="flex items-center gap-3 text-sm text-brand-400"
                  >
                    <span className="text-accent font-bold">✓</span>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="bg-black/40 p-4 rounded-md border border-brand-200">
              <div className="flex items-start gap-3 text-brand-400 text-xs">
                <ShieldCheck className="w-5 h-5 text-accent mt-0.5 flex-shrink-0" />
                <p>
                  Nuestra arquitectura cumple con los más altos estándares
                  corporativos de seguridad B2B.
                </p>
              </div>
            </div>
          </div>

          {/* Checkout Side */}
          <div className="p-10 md:p-14 md:w-3/5 bg-transparent flex flex-col justify-center relative">
            <div className="text-center mb-8">
              <h4 className="font-bold text-accent uppercase tracking-widest text-sm">
                Acceso Seguro
              </h4>
              <p className="text-sm text-brand-400 mt-2">
                Finaliza tu solicitud para iniciar el proceso
              </p>
            </div>

            {cart.length > 0 && (
              <div className="bg-brand-900 border border-brand-200 rounded-lg p-4 mb-6">
                <h5 className="text-[10px] uppercase font-bold tracking-widest text-brand-500 mb-3 block">
                  Resumen del Carrito
                </h5>
                <ul className="space-y-2 mb-4 border-b border-brand-200 pb-4">
                  {cart.map((item, i) => (
                    <li
                      key={i}
                      className="flex justify-between items-center text-xs"
                    >
                      <span className="text-white truncate pr-4">
                        {item.title}
                      </span>
                      <div className="flex items-center gap-3 flex-shrink-0">
                        <span className="text-accent font-bold">
                          {item.price}
                        </span>
                        <button
                          onClick={() => removeFromCart(item.id)}
                          className="text-brand-500 hover:text-red-400"
                          title="Eliminar"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    </li>
                  ))}
                </ul>

                <div className="space-y-2 mb-4">
                  <div className="flex justify-between text-xs text-brand-400 font-bold uppercase tracking-widest">
                    <span>Subtotal</span>
                    <span>{formatPrice(subtotal)}</span>
                  </div>
                  {activeCoupon && (
                    <div className="flex justify-between text-xs text-green-400 font-bold uppercase tracking-widest">
                      <span>
                        Descuento ({(activeCoupon.discount * 100).toFixed(0)}%)
                      </span>
                      <span>-{formatPrice(discountAmount)}</span>
                    </div>
                  )}
                  <div className="flex justify-between text-sm text-white font-bold uppercase tracking-widest pt-2 border-t border-brand-200">
                    <span>Total</span>
                    <div className="text-right">
                      {activeCoupon && (
                        <span className="text-[10px] text-brand-500 line-through mr-2">
                          {formatPrice(subtotal)}
                        </span>
                      )}
                      <span className="text-accent text-lg">
                        {formatPrice(totalAmount)}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="mb-4">
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-brand-500 mb-2">
                    ¿Tienes un código promocional?
                  </label>
                  <div className="flex gap-2 mb-2">
                    <input
                      type="text"
                      value={promoCode}
                      onChange={(e) => {
                        setPromoCode(e.target.value);
                        if (promoMessage) setPromoMessage(null);
                      }}
                      className="flex-1 bg-black/50 border border-brand-200 rounded px-3 py-2 text-xs text-white focus:border-accent focus:outline-none transition-colors uppercase"
                      disabled={!!activeCoupon}
                    />
                    <button
                      onClick={handleApplyPromo}
                      disabled={!!activeCoupon || !promoCode}
                      className="px-4 py-2 bg-brand-800 text-white text-[10px] font-bold uppercase tracking-widest rounded hover:bg-brand-700 transition-colors disabled:opacity-50"
                    >
                      {activeCoupon ? "Aplicado" : "Aplicar"}
                    </button>
                  </div>
                  {promoMessage && (
                    <p
                      className={`text-[10px] font-bold uppercase tracking-widest ${promoMessage.type === "success" ? "text-accent" : "text-red-400"}`}
                    >
                      {promoMessage.text}
                    </p>
                  )}
                </div>

                {cart.length > 2 && (
                  <div className="bg-brand-800/50 p-3 rounded text-[10px] text-accent font-semibold flex items-start gap-2 border border-brand-200 mt-4">
                    <p>
                      ⚙️ Optimización compleja detectada: Tiempo de entrega
                      estimado 25-30 min
                    </p>
                  </div>
                )}
              </div>
            )}

            {/* Payment Section */}
            {cart.length > 0 && (
              <div className="mb-6">
                <h5 className="text-[10px] uppercase font-bold tracking-widest text-brand-500 mb-3 block">
                  Método de Pago
                </h5>
                <div className="space-y-4 mb-6">
                  {/* Opción B: Tarjeta (No disponible) */}
                  <label className="block border border-brand-200/30 rounded-lg p-4 cursor-not-allowed bg-brand-900/50 opacity-70 transition-all relative overflow-hidden">
                    <div className="absolute inset-0 bg-black/20 z-0"></div>
                    <div className="relative z-10 flex flex-col gap-3">
                      <div className="flex items-center justify-between">
                        <p className="text-xs font-bold text-white uppercase tracking-widest flex items-center gap-2">
                          Tarjeta de Crédito / Débito
                        </p>
                        <span className="bg-brand-800 text-brand-400 border border-brand-400 text-[9px] px-1.5 py-0.5 rounded">
                          PRÓXIMAMENTE
                        </span>
                      </div>
                      <div className="flex gap-2 items-center flex-wrap mt-1 opacity-60">
                        <div
                          className="bg-white/10 rounded-sm flex items-center justify-center p-1"
                          title="Mastercard"
                        >
                          <FaCcMastercard className="w-6 h-6 text-white" />
                        </div>
                        <div
                          className="bg-white/10 rounded-sm flex items-center justify-center p-1"
                          title="Visa"
                        >
                          <FaCcVisa className="w-6 h-6 text-white" />
                        </div>
                        <div
                          className="bg-white/10 rounded-sm flex items-center justify-center p-1"
                          title="Apple Pay"
                        >
                          <FaApplePay className="w-6 h-6 text-white" />
                        </div>
                        <div
                          className="bg-white/10 rounded-sm flex items-center justify-center p-1"
                          title="American Express"
                        >
                          <FaCcAmex className="w-6 h-6 text-white" />
                        </div>
                      </div>
                      <p className="text-[10px] text-brand-500 font-mono tracking-widest uppercase mt-2">
                        Esta opción de pago estará disponible pronto.
                      </p>
                    </div>
                  </label>

                  {/* Opción A: Transferencia */}
                  <label className="block border border-accent rounded-lg p-4 cursor-pointer bg-brand-900 shadow-[0_0_10px_rgba(202,255,0,0.1)] transition-all">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="flex-1">
                        <p className="text-xs font-bold text-white uppercase tracking-widest flex items-center gap-2">
                          Transferencia Bancaria{" "}
                          <span className="bg-accent text-black text-[9px] px-1.5 py-0.5 rounded ml-2">
                            RECOMENDADO
                          </span>
                        </p>
                      </div>
                    </div>

                    <div className="bg-black/50 p-4 border border-brand-200 rounded text-xs text-brand-300 font-mono tracking-widest leading-loose uppercase">
                      <p>
                        <span className="text-brand-500 font-bold">Banco:</span>{" "}
                        Banco Santander
                      </p>
                      <p>
                        <span className="text-brand-500 font-bold">
                          Tipo de Cuenta:
                        </span>{" "}
                        Cuenta Más Lucas
                      </p>
                      <p className="flex items-center justify-between">
                        <span className="text-brand-500 font-bold">
                          N° Cuenta:
                        </span>{" "}
                        0 056 24 06923 0
                      </p>
                      <p className="flex items-center justify-between">
                        <span className="text-brand-500 font-bold">RUT:</span>{" "}
                        24.069.230-9
                      </p>
                      <p className="flex items-center justify-between">
                        <span className="text-brand-500 font-bold">
                          Nombre:
                        </span>{" "}
                        Dilan Alejandro Perez Canales
                      </p>
                    </div>

                    <div className="mt-4 bg-brand-800/80 p-3 rounded border border-brand-200">
                      <p className="text-[10px] text-brand-400 font-bold leading-relaxed">
                        🛡️ COMPRA 100% SEGURA: Una vez finalizada la
                        transferencia, debes enviar el comprobante de inmediato
                        vía WhatsApp para activar tu servicio. IMPORTANTE:
                        REWEAR nunca te solicitará claves bancarias ni datos
                        privados por ningún medio.
                      </p>
                    </div>
                  </label>
                </div>

                <button
                  onClick={handleCheckout}
                  className="w-full flex items-center justify-center p-4 text-lg font-bold uppercase tracking-widest rounded-md transition-all shadow-[0_0_20px_rgba(202,255,0,0.3)] bg-accent text-black hover:bg-brand-400 hover:scale-[1.02] mb-4"
                >
                  <ShoppingCart className="w-5 h-5 mr-3" /> Reportar Pago y
                  Continuar
                </button>

                <div className="bg-brand-900 border border-brand-200/50 p-3 rounded-lg text-center">
                  <p className="text-white text-[11px] font-bold">
                    ✅ GARANTÍA TOTAL: Si no estás satisfecho con el resultado,
                    te devolvemos tu dinero sin preguntas.
                  </p>
                </div>
              </div>
            )}

            <div className="border-t border-brand-200 pt-6 mt-4">
              <div className="flex items-center justify-between text-[10px] text-brand-400 uppercase tracking-widest">
                <div className="flex gap-2 items-center flex-wrap">
                  <div
                    className="bg-white/10 rounded-sm flex items-center justify-center p-1"
                    title="Mastercard"
                  >
                    <FaCcMastercard className="w-5 h-5 text-white" />
                  </div>
                  <div
                    className="bg-white/10 rounded-sm flex items-center justify-center p-1"
                    title="Visa"
                  >
                    <FaCcVisa className="w-5 h-5 text-white" />
                  </div>
                  <div
                    className="bg-white/10 rounded-sm flex items-center justify-center p-1"
                    title="Apple Pay"
                  >
                    <FaApplePay className="w-5 h-5 text-white" />
                  </div>
                  <div
                    className="bg-white/10 rounded-sm flex items-center justify-center p-1"
                    title="American Express"
                  >
                    <FaCcAmex className="w-5 h-5 text-white" />
                  </div>
                  <div className="w-8 h-7 bg-white/10 rounded-sm flex items-center justify-center">
                    <Lock className="w-3 h-3 text-white" />
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  🔒 SSL 256-bit Encrypted
                </div>
              </div>
            </div>
          </div>
        </div>
      </motion.section>

      {/* Feedback Questionnaire Section */}
      <motion.section
        className="py-20 text-white mt-10 relative z-10"
        initial={{ opacity: 0, y: 40 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-100px" }}
        transition={{ duration: 0.8, ease: "easeOut" }}
      >
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-brand-400 font-bold uppercase tracking-widest text-xs mb-2">
            Feedback Express
          </p>
          <h2 className="text-white text-3xl font-anton uppercase tracking-widest mb-8">
            ¿Qué le parece nuestra propuesta de valor?
          </h2>

          <div className="bg-black/40 backdrop-blur-md rounded-xl p-8 border border-brand-200 shadow-xl min-h-[160px] flex items-center justify-center">
            <AnimatePresence mode="wait">
              {!feedbackSubmitted ? (
                <motion.div
                  key="form"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  className="w-full flex flex-col sm:flex-row justify-center gap-4"
                >
                  <button
                    onClick={() => setFeedbackSubmitted(true)}
                    className="flex-1 py-3 text-sm font-bold uppercase tracking-widest text-white border border-brand-200 rounded-md hover:bg-brand-100 transition-colors"
                  >
                    Excelente
                  </button>
                  <button
                    onClick={() => setFeedbackSubmitted(true)}
                    className="flex-1 py-3 text-sm font-bold uppercase tracking-widest text-white border border-brand-200 rounded-md hover:bg-brand-100 transition-colors"
                  >
                    Interesante
                  </button>
                  <button
                    onClick={() => setFeedbackSubmitted(true)}
                    className="flex-1 py-3 text-sm font-bold uppercase tracking-widest text-white border border-brand-200 rounded-md hover:bg-brand-100 transition-colors"
                  >
                    Dudas
                  </button>
                </motion.div>
              ) : (
                <motion.div
                  key="thanks"
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="text-center"
                >
                  <CheckCircle2 className="w-12 h-12 text-accent mx-auto mb-4" />
                  <h3 className="font-bold uppercase tracking-widest text-white text-lg">
                    ¡Gracias por tu respuesta!
                  </h3>
                  <p className="text-brand-400 mt-2 text-sm">
                    Un asesor se pondrá en contacto pronto si lo requieres.
                  </p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </motion.section>

      {/* Testimonials */}
      <motion.section
        className="py-24 bg-brand-900/40 border-b border-brand-200 relative z-10"
        initial={{ opacity: 0, y: 40 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
      >
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="font-anton text-4xl md:text-5xl uppercase tracking-widest text-white mb-4">
              Opiniones y <span className="text-accent">Reseñas</span>
            </h2>
            <p className="text-brand-400 text-sm md:text-base">
              Nuestra transparencia es nuestro mejor código. Lo que dicen
              quienes ya automatizaron con nosotros.
            </p>
          </div>

          <div
            className="relative bg-black/40 border border-brand-200 rounded-xl p-8 md:p-12 overflow-hidden shadow-2xl"
            onMouseEnter={() => setIsHoveringReviews(true)}
            onMouseLeave={() => setIsHoveringReviews(false)}
          >
            <AnimatePresence mode="wait">
              {[
                {
                  name: "Juan C.",
                  role: "Agencia de Marketing",
                  msg: "Increíble la velocidad. Pensé que el bot tardaría semanas y en 15 minutos ya estaba respondiendo clientes.",
                  rating: 5,
                },
                {
                  name: "María F.",
                  role: "Tienda E-Commerce",
                  msg: "Tuve un susto porque el checkout falló, pero el servicio de emergencia lo levantó rapidísimo. Buen soporte.",
                  rating: 4,
                },
                {
                  name: "Carlos T.",
                  role: "Consultoría B2B",
                  msg: "Profesionales y transparentes. Me explicaron la integración paso a paso y la ejecución fue impecable.",
                  rating: 5,
                },
              ].map(
                (review, i) =>
                  i === currentReviewIndex && (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 20 }}
                      transition={{ duration: 0.5 }}
                      className="flex flex-col items-center text-center"
                    >
                      <div className="flex text-accent mb-6">
                        {[...Array(review.rating)].map((_, j) => (
                          <Star key={j} className="w-5 h-5 fill-current" />
                        ))}
                        {[...Array(5 - review.rating)].map((_, j) => (
                          <Star key={j} className="w-5 h-5 text-brand-700" />
                        ))}
                      </div>
                      <p className="text-white text-lg md:text-xl md:leading-relaxed font-bold tracking-wide italic mb-8">
                        "{review.msg}"
                      </p>
                      <div className="border-t border-brand-200 pt-6 w-16 mx-auto mb-4"></div>
                      <div>
                        <p className="text-white font-bold text-sm uppercase tracking-widest mb-1">
                          {review.name}
                        </p>
                        <p className="text-brand-500 text-[10px] uppercase font-semibold">
                          {review.role}
                        </p>
                      </div>
                    </motion.div>
                  ),
              )}
            </AnimatePresence>

            <div className="flex justify-center gap-2 mt-8">
              {[0, 1, 2].map((i) => (
                <button
                  key={i}
                  onClick={() => setCurrentReviewIndex(i)}
                  className={`w-2 h-2 rounded-full transition-all ${i === currentReviewIndex ? "bg-accent w-6" : "bg-brand-600 hover:bg-brand-400"}`}
                />
              ))}
            </div>
          </div>
        </div>
      </motion.section>

      {/* Footer */}
      <footer className="border-t border-brand-200 py-6 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col items-center gap-6">
          <div className="flex flex-col md:flex-row justify-between items-center w-full text-[10px] uppercase tracking-widest text-brand-400 gap-4">
            <div>
              &copy; {new Date().getFullYear()} REWEAR GLOBAL SYSTEMS. TODOS LOS
              DERECHOS RESERVADOS.
            </div>

            <div className="flex flex-wrap items-center justify-center gap-4 sm:gap-6">
              <a
                href="/Aviso_Legal_REWEAR.pdf"
                target="_blank"
                rel="noreferrer"
                className="hover:text-white transition-colors"
              >
                Aviso Legal
              </a>
              <a
                href="/Politica_Privacidad_REWEAR.pdf"
                target="_blank"
                rel="noreferrer"
                className="hover:text-white transition-colors"
              >
                Privacidad
              </a>
              <a
                href="/SLA_REWEAR_Global_Solution.pdf"
                target="_blank"
                rel="noreferrer"
                className="hover:text-white transition-colors"
              >
                SLA Agreement
              </a>
              <a
                href="https://forms.gle/baU7zHUcvj2MpXPU8"
                target="_blank"
                rel="noreferrer"
                className="text-accent hover:text-brand-400 transition-colors font-bold"
              >
                TRABAJA CON NOSOTROS
              </a>
            </div>
          </div>

          <div className="flex items-center gap-6 mt-2">
            <a
              href="https://www.facebook.com/rewear.global2"
              target="_blank"
              rel="noreferrer"
              className="text-brand-400 hover:text-accent transition-colors"
            >
              <FaFacebook className="w-5 h-5" />
            </a>
            <a
              href="https://www.instagram.com/rewearglobal/"
              target="_blank"
              rel="noreferrer"
              className="text-brand-400 hover:text-accent transition-colors"
            >
              <FaInstagram className="w-5 h-5" />
            </a>
            <a
              href="https://www.youtube.com/channel/UC-W1TsLmWDx5VGdxGzw4NqQ"
              target="_blank"
              rel="noreferrer"
              className="text-brand-400 hover:text-accent transition-colors"
            >
              <FaYoutube className="w-5 h-5" />
            </a>
            <a
              href="https://www.linkedin.com/in/rewear-global-763981389/"
              target="_blank"
              rel="noreferrer"
              className="text-brand-400 hover:text-accent transition-colors"
            >
              <FaLinkedin className="w-5 h-5" />
            </a>
            <a
              href="mailto:contacto.rewear@proton.me"
              className="text-brand-400 hover:text-accent transition-colors"
            >
              <FaEnvelope className="w-5 h-5" />
            </a>
          </div>
        </div>
      </footer>
      <AIChat />
    </div>
  );
}
