import React, { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { MessageSquare, X, Send, Bot, User } from "lucide-react";
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

const SYSTEM_INSTRUCTION = `Eres el 'Asesor Tecnológico AI' oficial de REWEAR. 
Tu misión es ayudar a los usuarios a entender nuestros servicios, cotizar y resolver dudas.
Eres profesional, vas al grano y usas un tono tecnológico pero accesible.

Servicios de REWEAR:
- INTEGRACIÓN MERCADO PAGO O WEBPAY: $29.990 (Pago seguro en WordPress, Shopify, código propio).
- RECUPERADOR AUTOMATIZADO DE CARRITOS: $34.990 (Secuencia de WhatsApp para recuperar ventas perdidas).
- CHATBOT VENTAS BÁSICO: $14.990 (Chatbot en redes sociales o web basado en reglas).
- CHATBOT AUTOMATIZADO BÁSICO + INSTALACIÓN (WHATSAPP O WEB): $14.990 (Menú de bienvenida corporativo).
- AUTOMATIZACIONES IA + CHATBOT: $60.000 (Agente IA conversacional tipo ChatGPT para atención 24/7 humana).
- SITIO WEB CORPORATIVO EXPRESS (CON IA): $49.990 (Sitio web autoadministrable, optimizado, rápido).
- OTROS/A MEDIDA: Presupuesto desde $7.990.

Horarios de atención humana:
- Lunes a Jueves: 17:30 - 20:30
- Viernes: 14:20 - 17:30
- Sábado: 08:00 - 12:00

Reglas:
- Si el usuario quiere comprar, dile que seleccione los servicios en la página y luego envíe el mensaje por WhatsApp.
- Respuestas breves, directas, usa viñetas si es necesario.
- No inventes precios ni servicios que no estén en la lista.`;

export function AIChat() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<
    { role: "user" | "model"; text: string }[]
  >([
    {
      role: "model",
      text: "¡Hola! Soy el Asesor AI de REWEAR. ¿En qué te puedo ayudar hoy?",
    },
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMsg = input.trim();
    setInput("");
    setMessages((prev) => [...prev, { role: "user", text: userMsg }]);
    setIsLoading(true);

    try {
      // Build history for context
      const chatHistory = messages
        .map((m) => `${m.role === "user" ? "Usuario" : "Asesor"}: ${m.text}`)
        .join("\n");

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `${chatHistory}\nUsuario: ${userMsg}\nAsesor:`,
        config: {
          systemInstruction: SYSTEM_INSTRUCTION,
          temperature: 0.7,
        },
      });

      setMessages((prev) => [
        ...prev,
        {
          role: "model",
          text:
            response.text ||
            "Lo siento, tuve un problema procesando tu mensaje. Intenta nuevamente.",
        },
      ]);
    } catch (error) {
      console.error("AI Error:", error);
      setMessages((prev) => [
        ...prev,
        {
          role: "model",
          text: "Ocurrió un error al contactar al cerebro AI. Por favor, inténtalo más tarde.",
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <AnimatePresence>
        {!isOpen && (
          <motion.button
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0, opacity: 0 }}
            onClick={() => setIsOpen(true)}
            className="fixed bottom-6 left-6 z-50 bg-accent text-black p-4 rounded-full shadow-[0_0_20px_rgba(202,255,0,0.4)] hover:bg-brand-400 hover:scale-110 transition-all flex items-center justify-center group"
          >
            <MessageSquare className="w-6 h-6" />
            <span className="absolute left-full ml-4 bg-black/90 text-accent text-[10px] uppercase font-bold tracking-widest px-3 py-1.5 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap border border-brand-200">
              Asesor AI
            </span>
          </motion.button>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="fixed bottom-6 left-6 z-50 w-[340px] h-[500px] max-h-[80vh] bg-black/60 backdrop-blur-3xl border border-brand-200/50 rounded-2xl shadow-[0_8_32px_rgba(0,0,0,0.5)] flex flex-col overflow-hidden"
          >
            {/* Header */}
            <div className="p-4 border-b border-brand-200/30 bg-black/40 flex justify-between items-center backdrop-blur-md">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full border border-accent flex items-center justify-center overflow-hidden">
                  <img
                    src="https://images.unsplash.com/photo-1675252277494-1a9becc4407b?q=80&w=200&auto=format&fit=crop"
                    alt="AI Agent"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <h3 className="text-white text-xs font-bold uppercase tracking-widest">
                    Asesor AI
                  </h3>
                  <p className="text-brand-500 text-[9px] uppercase tracking-widest flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></span>{" "}
                    En línea
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsOpen(false)}
                className="text-brand-400 hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 font-montserrat">
              {messages.map((msg, idx) => (
                <div
                  key={idx}
                  className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-[85%] rounded-2xl p-3 text-sm ${
                      msg.role === "user"
                        ? "bg-accent text-black rounded-tr-none shadow-[0_4_12px_rgba(202,255,0,0.2)]"
                        : "bg-black/50 border border-brand-200/30 text-brand-300 rounded-tl-none leading-relaxed shadow-[0_4_12px_rgba(0,0,0,0.3)] backdrop-blur-sm" // Custom styling
                    }`}
                  >
                    {msg.text}
                  </div>
                </div>
              ))}
              {isLoading && (
                <div className="flex justify-start">
                  <div className="max-w-[85%] bg-black/50 border border-brand-200/30 shadow-[0_4_12px_rgba(0,0,0,0.3)] backdrop-blur-sm rounded-2xl rounded-tl-none p-4 flex gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-accent animate-bounce"></span>
                    <span
                      className="w-1.5 h-1.5 rounded-full bg-accent animate-bounce"
                      style={{ animationDelay: "0.2s" }}
                    ></span>
                    <span
                      className="w-1.5 h-1.5 rounded-full bg-accent animate-bounce"
                      style={{ animationDelay: "0.4s" }}
                    ></span>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* InputArea */}
            <div className="p-3 bg-black/40 backdrop-blur-md border-t border-brand-200/30">
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  handleSend();
                }}
                className="flex gap-2"
              >
                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Escribe tu consulta..."
                  className="flex-1 bg-black/50 border border-brand-200/30 rounded-full px-4 py-2 text-xs text-white focus:outline-none focus:border-accent transition-colors w-full"
                />
                <button
                  type="submit"
                  disabled={isLoading || !input.trim()}
                  className="w-10 h-10 rounded-full bg-accent text-black flex items-center justify-center flex-shrink-0 hover:bg-brand-400 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <Send className="w-4 h-4 ml-0.5" />
                </button>
              </form>
            </div>

            {/* Disclaimer */}
            <div className="bg-black/60 backdrop-blur-sm py-1.5 text-center border-t border-brand-200/30">
              <p className="text-[8px] text-brand-500 uppercase tracking-widest">
                AI Agent - Las respuestas pueden ser imprecisas
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
