import React, { useState, useEffect } from "react";
import { motion } from "motion/react";
import { FaEye, FaEyeSlash } from "react-icons/fa";
import { Lock, Mail, User } from "lucide-react";

interface AuthScreenProps {
  onLogin: (email: string) => void;
}

export function AuthScreen({ onLogin }: AuthScreenProps) {
  const [isLogin, setIsLogin] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [passwordStrength, setPasswordStrength] = useState(0);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Simple password strength calculation
    let strength = 0;
    if (password.length >= 8) strength++;
    if (/[A-Z]/.test(password)) strength++;
    if (/[0-9]/.test(password)) strength++;
    if (/[^A-Za-z0-9]/.test(password)) strength++;
    setPasswordStrength(strength);
  }, [password]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      if (!email || !password) {
        throw new Error("Por favor, ingresa correo y contraseña.");
      }
      // Simple mock logic
      onLogin(email);
    } catch (err: any) {
      console.error("Auth error:", err);
      setError("Acceso Denegado: " + err.message);
    }
  };

  return (
    <div className="min-h-screen bg-[#050505] flex items-center justify-center p-4 relative overflow-hidden font-montserrat tracking-wide">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.2 }}
        className="w-full max-w-md relative z-10"
      >
        <div className="bg-black/80 backdrop-blur-3xl border border-white/10 p-10 rounded-3xl shadow-[0_0_60px_rgba(255,255,255,0.05)]">
          <div className="text-center mb-10">
            <img
              src="/logo submarcado sin fondo.png"
              alt="REWEAR"
              className="h-12 mx-auto mb-6 object-contain"
              onError={(e) => (e.currentTarget.style.display = "none")}
            />
            <h2 className="text-xl font-black uppercase tracking-[0.15em] text-white mb-2">
              {isLogin ? "Bienvenido" : "Crear Cuenta"}
            </h2>
            <p className="text-[10px] text-white/50 uppercase tracking-widest font-mono">
              Acceso a REWEAR Global Solution
            </p>
          </div>

          {error && (
            <div className="mb-4 bg-red-500/10 border border-red-500/50 text-red-500 p-3 flex rounded-xl text-xs font-medium text-center justify-center">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {!isLogin && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                className="flex gap-4"
              >
                <div className="relative flex-1">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <User className="h-4 w-4 text-brand-500" />
                  </div>
                  <input
                    type="text"
                    required
                    placeholder="Nombre"
                    className="w-full bg-white/5 border border-white/10 rounded-xl pl-10 pr-4 py-3.5 text-white text-xs font-medium focus:outline-none focus:border-white focus:bg-white/10 transition-all placeholder:text-white/30"
                  />
                </div>
                <div className="relative flex-1">
                  <input
                    type="text"
                    required
                    placeholder="Apellido"
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3.5 text-white text-xs font-medium focus:outline-none focus:border-white focus:bg-white/10 transition-all placeholder:text-white/30"
                  />
                </div>
              </motion.div>
            )}

            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                <Mail className="h-4 w-4 text-white/50" />
              </div>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Correo Electrónico"
                className="w-full bg-white/5 border border-white/10 rounded-xl pl-10 pr-4 py-3.5 text-white text-xs font-medium focus:outline-none focus:border-white focus:bg-white/10 transition-all placeholder:text-white/30"
              />
            </div>

            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                <Lock className="h-4 w-4 text-white/50" />
              </div>
              <input
                type={showPassword ? "text" : "password"}
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Contraseña"
                className="w-full bg-white/5 border border-white/10 rounded-xl pl-10 pr-10 py-3.5 text-white text-xs font-medium focus:outline-none focus:border-white focus:bg-white/10 transition-all placeholder:text-white/30"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute inset-y-0 right-0 pr-4 flex items-center text-white/50 hover:text-white transition-colors"
              >
                {showPassword ? (
                  <FaEyeSlash className="h-4 w-4" />
                ) : (
                  <FaEye className="h-4 w-4" />
                )}
              </button>
            </div>

            {/* Password strength indicator */}
            {!isLogin && password.length > 0 && (
              <div className="space-y-1 mt-2">
                <div className="flex gap-1 h-1.5">
                  <div
                    className={`flex-1 rounded-full ${passwordStrength >= 1 ? "bg-red-500" : "bg-brand-800"}`}
                  ></div>
                  <div
                    className={`flex-1 rounded-full ${passwordStrength >= 2 ? "bg-yellow-500" : "bg-brand-800"}`}
                  ></div>
                  <div
                    className={`flex-1 rounded-full ${passwordStrength >= 3 ? "bg-accent" : "bg-brand-800"}`}
                  ></div>
                  <div
                    className={`flex-1 rounded-full ${passwordStrength >= 4 ? "bg-green-500" : "bg-brand-800"}`}
                  ></div>
                </div>
                <p className="text-[9px] text-brand-400 uppercase tracking-widest mt-1 text-right">
                  {passwordStrength < 2
                    ? "Débil"
                    : passwordStrength < 4
                      ? "Media"
                      : "Fuerte"}
                </p>
              </div>
            )}

            <button
              type="submit"
              className="w-full bg-white text-black font-bold uppercase tracking-widest text-xs py-3.5 rounded-xl hover:bg-gray-200 transition-colors mt-2"
            >
              {isLogin ? "Acceder a la plataforma" : "Crear mi cuenta"}
            </button>
          </form>

          <div className="mt-6 text-center">
            <button
              onClick={() => setIsLogin(!isLogin)}
              className="text-[10px] text-white/50 hover:text-white transition-colors uppercase tracking-widest font-bold"
            >
              {isLogin
                ? "¿No tienes cuenta? Regístrate"
                : "¿Ya tienes cuenta? Inicia sesión"}
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
