import React, { useState, useRef, useEffect } from "react";
import { motion } from "motion/react";

interface VerificationScreenProps {
  onVerify: () => void;
  onCancel: () => void;
  email: string | null;
}

export function VerificationScreen({
  onVerify,
  onCancel,
  email,
}: VerificationScreenProps) {
  const [code, setCode] = useState(["", "", "", "", "", ""]);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [demoCode, setDemoCode] = useState<string | null>(null);
  const [expiresAt, setExpiresAt] = useState<number | null>(null);
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  // Generate and save code on mount
  useEffect(() => {
    const generateCode = async () => {
      const generatedCode = Math.floor(
        100000 + Math.random() * 900000,
      ).toString();

      // We still store code to verify locally against the user's input
      setDemoCode(generatedCode);
      setExpiresAt(Date.now() + 10 * 60 * 1000); // 10 minutes

      try {
        await fetch("/api/send-code", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email: email || "user", code: generatedCode }),
        });
      } catch (err) {
        console.error("Error calling send-code:", err);
      }
    };
    generateCode();
  }, [email]);

  const handleChange = (index: number, value: string) => {
    if (value.length > 1) return; // Prevent multiple chars
    const newCode = [...code];
    newCode[index] = value;
    setCode(newCode);

    // Auto-focus next
    if (value && index < 5) {
      inputRefs.current[index + 1]?.focus();
    }
  };

  const handleKeyDown = (
    index: number,
    e: React.KeyboardEvent<HTMLInputElement>,
  ) => {
    if (e.key === "Backspace" && !code[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const enteredCode = code.join("");
    if (enteredCode.length !== 6) {
      setError("Por favor, ingresa el código completo de 6 dígitos.");
      return;
    }

    setLoading(true);
    setError(null);

    // Mock validation
    setTimeout(() => {
      if (expiresAt && Date.now() > expiresAt) {
        setError("El código ha expirado. Por favor, solicita uno nuevo.");
        setLoading(false);
      } else if (enteredCode === demoCode) {
        onVerify();
      } else {
        setError("Código incorrecto.");
        setLoading(false);
      }
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-[#020202] flex items-center justify-center p-4 relative overflow-hidden font-sans">
      {/* Background Gradients */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-accent/5 rounded-full blur-[120px] pointer-events-none" />

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md relative z-10"
      >
        <div className="bg-black/80 backdrop-blur-3xl border border-white/10 p-10 rounded-3xl shadow-[0_0_60px_rgba(255,255,255,0.05)]">
          <div className="text-center mb-10">
            <img
              src="/logo submarcado sin fondo.png"
              alt="REWEAR"
              className="h-12 mx-auto mb-6 object-contain"
              onError={(e) => (e.currentTarget.style.display = "none")}
            />
            <h2 className="text-xl font-black uppercase tracking-[0.15em] text-white mb-2">
              Verifica que eres tú
            </h2>
            <p className="text-white/50 text-xs mt-2">
              Hemos enviado un código de 6 dígitos a tu correo electrónico.
            </p>
          </div>

          {error && (
            <div className="mb-6 bg-red-500/10 border border-red-500/50 text-red-500 p-3 rounded-xl text-xs font-medium text-center">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-8">
            <div className="flex gap-2 sm:gap-3 justify-center">
              {code.map((digit, index) => (
                <input
                  key={index}
                  ref={(el) => {
                    inputRefs.current[index] = el;
                  }}
                  type="text"
                  maxLength={1}
                  value={digit}
                  onChange={(e) => handleChange(index, e.target.value)}
                  onKeyDown={(e) => handleKeyDown(index, e)}
                  className="w-10 h-14 sm:w-12 sm:h-16 text-center text-xl font-bold bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none focus:border-accent focus:bg-white/10 transition-all placeholder:text-white/30"
                  autoFocus={index === 0}
                />
              ))}
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-4 bg-accent hover:bg-brand-400 text-black rounded-xl text-xs font-bold uppercase tracking-widest transition-all hover:scale-[1.02] active:scale-[0.98] disabled:opacity-50 disabled:hover:scale-100 flex items-center justify-center gap-2"
            >
              {loading ? "Verificando..." : "Confirmar Código"}
            </button>
            <button
              type="button"
              onClick={onCancel}
              className="w-full py-4 bg-transparent hover:bg-white/5 border border-white/10 text-white rounded-xl text-xs font-bold uppercase tracking-widest transition-all hover:scale-[1.02] active:scale-[0.98] flex items-center justify-center gap-2"
            >
              Volver
            </button>
          </form>
        </div>
      </motion.div>
    </div>
  );
}
