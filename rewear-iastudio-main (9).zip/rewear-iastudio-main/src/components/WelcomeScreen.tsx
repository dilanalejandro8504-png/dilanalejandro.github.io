import React, { useEffect, useRef } from "react";
import { motion } from "motion/react";

interface WelcomeScreenProps {
  onDismiss: () => void;
  key?: string;
}

class Particle {
  x: number;
  y: number;
  directionX: number;
  directionY: number;
  size: number;
  color: string;
  canvas: HTMLCanvasElement;
  ctx: CanvasRenderingContext2D;
  mouse: { x: number | null; y: number | null; radius: number };

  constructor(
    x: number,
    y: number,
    directionX: number,
    directionY: number,
    size: number,
    color: string,
    canvas: HTMLCanvasElement,
    ctx: CanvasRenderingContext2D,
    mouse: { x: number | null; y: number | null; radius: number }
  ) {
    this.x = x;
    this.y = y;
    this.directionX = directionX;
    this.directionY = directionY;
    this.size = size;
    this.color = color;
    this.canvas = canvas;
    this.ctx = ctx;
    this.mouse = mouse;
  }

  draw() {
    this.ctx.beginPath();
    this.ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2, false);
    this.ctx.fillStyle = this.color;
    this.ctx.fill();
  }

  update() {
    if (this.x > this.canvas.width || this.x < 0) this.directionX = -this.directionX;
    if (this.y > this.canvas.height || this.y < 0) this.directionY = -this.directionY;

    if (this.mouse.x != null && this.mouse.y != null) {
      let dx = this.mouse.x - this.x;
      let dy = this.mouse.y - this.y;
      let distance = Math.sqrt(dx * dx + dy * dy);

      if (distance < this.mouse.radius + this.size) {
        if (this.mouse.x < this.x && this.x < this.canvas.width - this.size * 10) this.x += 2;
        if (this.mouse.x > this.x && this.x > this.size * 10) this.x -= 2;
        if (this.mouse.y < this.y && this.y < this.canvas.height - this.size * 10) this.y += 2;
        if (this.mouse.y > this.y && this.y > this.size * 10) this.y -= 2;
      }
    }

    this.x += this.directionX;
    this.y += this.directionY;
    this.draw();
  }
}

export function WelcomeScreen({ onDismiss }: WelcomeScreenProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const requestRef = useRef<number>();

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let particlesArray: Particle[] = [];
    const numberOfParticles = 120; // Ajusta este número si notas caídas de FPS

    const mouse = { x: null as number | null, y: null as number | null, radius: 150 };

    const handleResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      init();
    };

    const handleMouseMove = (event: MouseEvent) => {
      mouse.x = event.clientX;
      mouse.y = event.clientY;
    };
    
    // Si queremos seguir a touch también
    const handleTouchMove = (event: TouchEvent) => {
      if(event.touches.length > 0) {
        mouse.x = event.touches[0].clientX;
        mouse.y = event.touches[0].clientY;
      }
    };

    window.addEventListener("resize", handleResize);
    window.addEventListener("mousemove", handleMouseMove);
    window.addEventListener("touchmove", handleTouchMove);

    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    function init() {
      particlesArray = [];
      if(!canvas || !ctx) return;
      
      for (let i = 0; i < numberOfParticles; i++) {
        let size = Math.random() * 2 + 1;
        let x = Math.random() * (window.innerWidth - size * 2 - size * 2) + size * 2;
        let y = Math.random() * (window.innerHeight - size * 2 - size * 2) + size * 2;
        let directionX = Math.random() * 2 - 1;
        let directionY = Math.random() * 2 - 1;
        let color = "#444444";

        particlesArray.push(
          new Particle(x, y, directionX, directionY, size, color, canvas, ctx, mouse)
        );
      }
    }

    function connect() {
      if(!canvas || !ctx) return;
      for (let a = 0; a < particlesArray.length; a++) {
        for (let b = a; b < particlesArray.length; b++) {
          let distance =
            (particlesArray[a].x - particlesArray[b].x) * (particlesArray[a].x - particlesArray[b].x) +
            (particlesArray[a].y - particlesArray[b].y) * (particlesArray[a].y - particlesArray[b].y);
          if (distance < (canvas.width / 7) * (canvas.height / 7)) {
            let opacityValue = 1 - distance / 20000;
            ctx.strokeStyle = `rgba(150, 150, 150, ${opacityValue})`;
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(particlesArray[a].x, particlesArray[a].y);
            ctx.lineTo(particlesArray[b].x, particlesArray[b].y);
            ctx.stroke();
          }
        }
      }
    }

    const animate = () => {
      requestRef.current = requestAnimationFrame(animate);
      ctx.clearRect(0, 0, window.innerWidth, window.innerHeight);
      for (let i = 0; i < particlesArray.length; i++) {
        particlesArray[i].update();
      }
      connect();
    };

    init();
    animate();

    return () => {
      window.removeEventListener("resize", handleResize);
      window.removeEventListener("mousemove", handleMouseMove);
      window.removeEventListener("touchmove", handleTouchMove);
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, []);

  return (
    <motion.div
      initial={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 1, ease: [0.77, 0, 0.175, 1] }}
      className="fixed inset-0 w-screen h-screen bg-[#0a0a0a] z-[9999] flex justify-center items-center overflow-hidden"
    >
      <canvas
        ref={canvasRef}
        className="absolute top-0 left-0 w-full h-full z-[1]"
      />
      <div className="relative z-[2] text-center text-white flex flex-col items-center">
        <h1 
          className="text-5xl md:text-[5rem] font-black uppercase tracking-[5px] m-0 mb-2 drop-shadow-lg"
          style={{ textShadow: "2px 2px 0px rgba(0, 102, 255, 0.5), -2px -2px 0px rgba(255, 0, 51, 0.5)" }}
        >
          REWEAR
        </h1>
        <h2 className="text-xl md:text-2xl font-light tracking-[8px] mt-[-10px] text-[#a0a0a0] uppercase">
          GLOBAL SOLUTION
        </h2>
        <p className="text-base text-[#777] mb-10 mt-4 max-w-md mx-auto">
          Innovación y escalabilidad a tu alcance.
        </p>
        <button
          onClick={onDismiss}
          className="px-10 py-4 text-base font-bold tracking-[2px] text-white bg-transparent border border-[#333] cursor-pointer relative overflow-hidden transition-all duration-300 hover:border-[#0066ff] hover:shadow-[0_0_15px_rgba(0,102,255,0.4)] hover:bg-[#0066ff]/10 uppercase"
        >
          Iniciar Experiencia
        </button>
      </div>
    </motion.div>
  );
}
